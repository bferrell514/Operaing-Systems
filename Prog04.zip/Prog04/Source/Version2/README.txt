Build procedure
	gcc -o prog04v02 prog04v02.c