Build procedure
	gcc -o prog04v03 prog04v03.c
	gcc -o prog04v03_distribute prog04v03_distribute.c
	gcc -o prog04v03_process prog04v03_process.c