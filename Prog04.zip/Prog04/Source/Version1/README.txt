Build procedure
	gcc -o prog04v01 prog04v01.c