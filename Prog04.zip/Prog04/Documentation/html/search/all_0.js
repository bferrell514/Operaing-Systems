var searchData=
[
  ['appendtrailingextension_0',['appendTrailingExtension',['../prog04v03_8c.html#ab2e4aec2921ea7f19212d10a48a2a9a6',1,'prog04v03.c']]],
  ['appendtrailingslash_1',['appendTrailingSlash',['../prog04v03_8c.html#a327270c44c06b20641b762c821998192',1,'prog04v03.c']]]
];
